﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Code.ViewModels
{
    public class PopupChonThietBiViewModel:INotifyPropertyChanged
    {
        private bool _IsSelected = false;
        private int _SoThuTu { get; set; }
        private string _MaThietBi { get; set; }

        public string MaThietBi
        {
            get { return _MaThietBi;}
            set { _MaThietBi = value; OnChanged("MaThietBi"); }
        }
        public bool IsSelected
        {
            get { return _IsSelected; }
            set
            {
                _IsSelected = value;
                OnChanged("IsSelected");
            }
        }
        public int SoThuTu
        {
            get { return _SoThuTu;}
            set { _SoThuTu = value; OnChanged("SoThuTu"); }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnChanged(string prop)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(prop));
        }
    }
}
