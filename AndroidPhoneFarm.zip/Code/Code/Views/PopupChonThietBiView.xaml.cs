﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Code.ViewModels;

namespace Code.Views
{
    /// <summary>
    /// Interaction logic for PopupChonThietBiView.xaml
    /// </summary>
    public partial class PopupChonThietBiView : Window
    {
        public PopupChonThietBiView()
        {
            List<PopupChonThietBiViewModel> tmp = new List<PopupChonThietBiViewModel>();
            tmp.Add(new PopupChonThietBiViewModel()
            {
                SoThuTu = 1,
                MaThietBi = "One"
            });
            tmp.Add(new PopupChonThietBiViewModel()
            {
                SoThuTu = 2,
                MaThietBi = "Two"
            });
            tmp.Add(new PopupChonThietBiViewModel()
            {
                SoThuTu = 3,
                MaThietBi = "Three"
            });
            
            InitializeComponent();
            dgThietBi.ItemsSource = tmp;
        }

        private void chkSelectAll_Unchecked(object sender, RoutedEventArgs e)
        {
            foreach (PopupChonThietBiViewModel c in dgThietBi.ItemsSource)
            {
                c.IsSelected = false;
            }
        }

        private void chkSelectAll_Checked(object sender, RoutedEventArgs e)
        {
            foreach (PopupChonThietBiViewModel c in dgThietBi.ItemsSource)
            {
                c.IsSelected = true;
            }
        }

        private void btnStart_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
